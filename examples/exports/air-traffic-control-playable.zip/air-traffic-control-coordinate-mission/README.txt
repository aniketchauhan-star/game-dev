Air Traffic Control — Coordinate Mission — playable game (version 1)
Exported from NEXUS Play Studio.

HOW TO PLAY LOCALLY
  This is a static website. Serve this folder with any static web server and open index.html, for example:
    npx serve .            (Node.js)
    python3 -m http.server (Python)
  It also works from a sub-folder of an existing website (all paths are relative).

HOSTING
  Upload the whole folder to any static host (school LMS file area, GitHub Pages, Netlify, S3…).
  No server code, learner login or AI service is needed — gameplay never calls Claude.

CONTENTS
  index.html        entry point
  game.config.js    the game (generated from game.config.json in the source package)
  runtime/          the NEXUS game runtime (HTML/CSS/JS/SVG, no external dependencies)
  assets/           images and audio used by the game
  PREFLIGHT.md      checks that ran when this export was created

# TASKS

## Requested next changes
Implement the memory-card mechanic as a new scene type.

## Build the custom mechanic

A memory card game: learners flip two cards; a pair matches when the point lies in the named quadrant.

Implement it as a new, allowlisted scene type in the runtime with deterministic rules, keyboard and non-drag alternatives, and tests.

## Known limitations
- The export preflight does not run browser tests; playtest in a browser.
- Images are used as supplied; check licensing before publishing.

# Game design — Quadrant Memory


**Core mechanic:** Describe another idea (blueprint only — no in-app builder yet)
**Blueprint revision:** r1

## Premise
Not written yet — describe the story premise.

## Why this mechanic fits
Not written yet — explain why the chosen interaction fits this lesson.

## Learning outcomes
- Identify the quadrant of a point from the signs of its coordinates. _(source: slide 1, slide 2, slide 3, slide 4, slide 5, slide 7, slide 8, slide 9)_

## Progression
Not written yet — describe how support fades and difficulty grows.

## Assessment
Not written yet — describe how understanding is checked.

## Scene flow
Title screen → Air Traffic Control: Coordinate Mission → The airfield is a coordinate plane → Reading an ordered pair (x, y) → The four quadrants → Negative coordinates → Tower to runway: plotting steps → Extension: distance between two aircraft → Mission practice → Completion screen

### 1. Air Traffic Control: Coordinate Mission — Concept card (discover)
- **Source:** slide 1
- **Objective:** Understand: Air Traffic Control: Coordinate Mission
- **Learner sees:** Concept card with the key points from slide 1.
- **Learner does:** Read the card and continue.
- **Expected result:** The learner continues to the next scene.
- **Success rule:** Continue after reading
- **Instruction:** “Air Traffic Control: Coordinate Mission”
- **Error feedback:** “Read the card, then continue.”
- **Hints:** “Read each point, then continue.”
- **Completion:** The learner selects Continue.
- **Locks:** sequence

### 2. The airfield is a coordinate plane — Concept card (discover)
- **Source:** slide 2
- **Objective:** Understand: The airfield is a coordinate plane
- **Learner sees:** Concept card with the key points from slide 2.
- **Learner does:** Read the card and continue.
- **Expected result:** The learner continues to the next scene.
- **Success rule:** Continue after reading
- **Instruction:** “The airfield is a coordinate plane”
- **Error feedback:** “Read the card, then continue.”
- **Hints:** “Read each point, then continue.”
- **Completion:** The learner selects Continue.
- **Locks:** sequence

### 3. Reading an ordered pair (x, y) — Concept card (discover)
- **Source:** slide 3
- **Objective:** Understand: Reading an ordered pair (x, y)
- **Learner sees:** Concept card with the key points from slide 3.
- **Learner does:** Read the card and continue.
- **Expected result:** The learner continues to the next scene.
- **Success rule:** Continue after reading
- **Instruction:** “Reading an ordered pair (x, y)”
- **Error feedback:** “Read the card, then continue.”
- **Hints:** “Read each point, then continue.”
- **Completion:** The learner selects Continue.
- **Locks:** sequence

### 4. The four quadrants — Concept card (discover)
- **Source:** slide 4
- **Objective:** Understand: The four quadrants
- **Learner sees:** Concept card with the key points from slide 4.
- **Learner does:** Read the card and continue.
- **Expected result:** The learner continues to the next scene.
- **Success rule:** Continue after reading
- **Instruction:** “The four quadrants”
- **Error feedback:** “Read the card, then continue.”
- **Hints:** “Read each point, then continue.”
- **Completion:** The learner selects Continue.
- **Locks:** sequence

### 5. Negative coordinates — Concept card (discover)
- **Source:** slide 5
- **Objective:** Understand: Negative coordinates
- **Learner sees:** Concept card with the key points from slide 5.
- **Learner does:** Read the card and continue.
- **Expected result:** The learner continues to the next scene.
- **Success rule:** Continue after reading
- **Instruction:** “Negative coordinates”
- **Error feedback:** “Read the card, then continue.”
- **Hints:** “Read each point, then continue.”
- **Completion:** The learner selects Continue.
- **Locks:** sequence

### 6. Tower to runway: plotting steps — Concept card (discover)
- **Source:** slide 7
- **Objective:** Understand: Tower to runway: plotting steps
- **Learner sees:** Concept card with the key points from slide 7.
- **Learner does:** Read the card and continue.
- **Expected result:** The learner continues to the next scene.
- **Success rule:** Continue after reading
- **Instruction:** “Tower to runway: plotting steps”
- **Error feedback:** “Read the card, then continue.”
- **Hints:** “Read each point, then continue.”
- **Completion:** The learner selects Continue.
- **Locks:** sequence

### 7. Extension: distance between two aircraft — Concept card (discover)
- **Source:** slide 8
- **Objective:** Understand: Extension: distance between two aircraft
- **Learner sees:** Concept card with the key points from slide 8.
- **Learner does:** Read the card and continue.
- **Expected result:** The learner continues to the next scene.
- **Success rule:** Continue after reading
- **Instruction:** “Extension: distance between two aircraft”
- **Error feedback:** “Read the card, then continue.”
- **Hints:** “Read each point, then continue.”
- **Completion:** The learner selects Continue.
- **Locks:** sequence

### 8. Mission practice — Concept card (discover)
- **Source:** slide 9
- **Objective:** Understand: Mission practice
- **Learner sees:** Concept card with the key points from slide 9.
- **Learner does:** Read the card and continue.
- **Expected result:** The learner continues to the next scene.
- **Success rule:** Continue after reading
- **Instruction:** “Mission practice”
- **Error feedback:** “Read the card, then continue.”
- **Hints:** “Read each point, then continue.”
- **Completion:** The learner selects Continue.
- **Locks:** sequence

## Accessibility requirements
- Every interaction must work with a keyboard and without dragging.

## Assumptions (not stated in the source)
- (none)

## Unresolved decisions
- (none)

# CLAUDE.md — Quadrant Memory

This folder is a NEXUS Play Studio handoff for Claude Code.

## Ground rules
- The approved design is **data** in `blueprint.json`. Built NEXUS games are data in `game.config.json`, rendered by the runtime (source in `runtime-src/`).
- Answer rules are allowlisted data evaluated by `runtime-src/shared/rules.ts`. Never add `eval`, `new Function`, or formulas from data.
- Keep learning content traceable: every scene lists `sourceSlideIds` (see `source-map.json`) or is marked `addedPractice`.
- Respect scene `locks` (sequence, wording, answer, layout, assets) unless the creator explicitly asks otherwise.
- Keep the game static: no network calls, no learner login, no API keys. Assets stay local under `assets/`.
- Keep the 1920×1080 logical stage and the existing accessibility behaviour: keyboard play, non-drag alternatives,
  text + icon feedback (never colour alone), reduced motion, audio only after the learner presses Start.

## This is a developer handoff
The chosen mechanic has no in-app builder, so there is no playable `game.config.json` and nothing to build yet.
Start from GAME_DESIGN.md and TASKS.md; implement the interaction as a new scene type following README.md.

- Animations are data in `game.config.json` → `motion` (allowlisted presets, triggers and parameters). Never add
  model-written scripts, CSS selectors, URLs or formulas; motion must not change scores, progress or answers.
- This handoff is for one grade version (see GRADE_PROFILE.md). Other grade versions are separate and must not be overwritten.

## Files
- GAME_DESIGN.md — design intent, scene flow, rules and feedback.
- TASKS.md — requested next changes and known gaps.
- ASSET_GUIDE.md — assets, roles, missing items and generation prompts.
- GRADE_PROFILE.md — who this version is for, its separate settings and the grade adaptations applied.
- ANIMATION_GUIDE.md — every animation as a readable rule, settings, runtime behaviour and what is unavailable.
- animation-manifest.json — the same animations as data, with validation results.
- design-map.json — Source-to-Screen map: slides, design frames (ids and nodes only) and artwork per screen.
- source-map.json — scene ↔ slide mapping (no speaker notes).

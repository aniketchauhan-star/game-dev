# ANIMATION GUIDE

There is no built game in this handoff, so there are no animations yet. Motion is added to a playable version in the studio's Animate workspace.

# ASSET GUIDE

## Assets in this export
| Name | Role | Kind | Size | Transparency | Source | File |
| --- | --- | --- | --- | --- | --- | --- |
| — | — | — | — | — | — | — |

Placement metadata (scale, rotation, anchor, crop) and sprite-sheet settings are in `asset-map.json`.

## Asset needs from the blueprint
- (none)

## Generation prompts
NEXUS does not generate images. If you need new artwork, these prompts can be pasted into an image tool of your choice:
- (all needs are assigned)

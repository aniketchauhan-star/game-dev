# Quadrant Memory — developer handoff

Exported from NEXUS Play Studio (approved blueprint r1).

The game idea uses an interaction that NEXUS cannot build in the app yet, so this package contains the
approved design — **not** a playable game. A developer implements the new interaction, then the game can be
built like any other NEXUS game.

## What is here

| Path | Purpose |
| --- | --- |
| `GAME_DESIGN.md` | Design intent, learning outcomes, scene flow, rules and feedback. Start here. |
| `TASKS.md` | The custom mechanic to build, requested changes and open questions. |
| `blueprint.json` | The approved blueprint as data (scenes, source slides, locks, asset needs). |
| `source-map.json` | Which slides each scene comes from (no speaker notes). |
| `ASSET_GUIDE.md`, `asset-map.json` | Asset roles, supplied files and missing items. |
| `runtime-src/` | TypeScript source of the NEXUS runtime and its rule engine — the reference for adding a scene type. |
| `CLAUDE.md` | Ground rules for working on this package with Claude Code. |

## Adding the new interaction

Follow the pattern of the existing scene types (coordinate navigation, drag-and-match, sequence sorting):

1. Describe it as data in `runtime-src/shared/schemas/interaction.ts` (a new `type` with a Zod schema).
2. Add an allowlisted rule evaluator in `runtime-src/shared/rules.ts` and an attainability check in
   `runtime-src/shared/attainability.ts` — rules are data, never formulas or code.
3. Register it in `runtime-src/shared/registry.ts` and render it in `runtime-src/runtime/scenes/`, with keyboard
   play, a non-drag alternative, text + icon feedback, and reduced-motion support.

## Not included

API keys, environment files, studio conversations, the original slide deck and speaker notes are never part of
this package unless “Include source material” was selected (then see `source-material/`).

# ASSET GUIDE

## Assets in this export
| Name | Role | Kind | Size | Transparency | Source | File |
| --- | --- | --- | --- | --- | --- | --- |
| trapezium | unassigned | image | 360×260 | yes | extracted | `assets/ast_1LmTQq5bPs2a.png` |
| parallelogram | unassigned | image | 360×260 | yes | extracted | `assets/ast_U31N44dXeEaF.png` |
| kite | unassigned | image | 360×260 | yes | extracted | `assets/ast_2XEj58iAphnE.png` |
| ice-background | background | image | 1920×1080 | yes | bundled-sample | `assets/ast_98nZwUnYsa5n.png` |
| Swiftee | character | image | 1280×512 | yes | bundled-sample | `assets/ast_cLBTVw0C57IS.png` |
| Blank ice panel | ui | image | 1000×320 | yes | bundled-sample | `assets/ast_Js11BNdBRuxG.png` |
| Ice button | ui | image | 360×110 | yes | bundled-sample | `assets/ast_9PW5MvDbInFl.png` |

Placement metadata (scale, rotation, anchor, crop) and sprite-sheet settings are in `asset-map.json`.

## Asset needs from the blueprint
- **Ice expedition background** (background) — assigned
- **Swiftee, the guide** (character) — assigned

## Generation prompts
NEXUS does not generate images. If you need new artwork, these prompts can be pasted into an image tool of your choice:
- (all needs are assigned)

# ANIMATION GUIDE

Animations are **data** (`game.config.json` → `motion`), validated by `runtime-src/shared/schemas/motion.ts` and run by the trusted runtime (`runtime-src/runtime/motion/`).
They are bound to runtime events (screen opened, control pressed, valid drop, correct answer, retry, completion…). Motion never submits answers, awards points, changes progress or replays sounds on its own.

## Settings

- Profile: **guided** · pacing: **standard** · decorative effects: **low**
- Animation sounds: on (volume 70%) — uploaded or bundled audio only, after the learner presses Start
- Reduced motion: follows the learner's device setting · low-effects mode: off

## Rules by screen

### Screen 1 · Title

- When Screen 1 · Title opens → fade the screen in.
  - `anim-title-scene-fade` · Fade · decorative · 320 ms · reduced motion: static · origin: preset
- When Screen 1 · Title opens → play Swiftee's “wave” clip once (after “Fade” on Whole screen).
  - `anim-title-character-` · Character clip · decorative · 1000 ms · reduced motion: static · origin: preset
- When Screen 1 · Title opens → pop Title card into view (after “Character clip” on Swiftee).
  - `anim-title-pop-in` · Pop in (restrained) · decorative · 320 ms · reduced motion: static · origin: preset

### Screen 2 · What is a trapezium?

- When Screen 2 · What is a trapezium? opens → fade the screen in.
  - `anim-scn-trap-int-scene-fade` · Fade · decorative · 320 ms · reduced motion: static · origin: preset
- When Screen 2 · What is a trapezium? opens → play Swiftee's “wave” clip once (after “Fade” on Whole screen).
  - `anim-scn-trap-int-character-` · Character clip · decorative · 1000 ms · reduced motion: static · origin: preset
- When Screen 2 · What is a trapezium? opens → reveal Key points step by step (after “Character clip” on Swiftee).
  - `anim-scn-trap-int-label-reve` · Step-by-step reveal · instructional · 1800 ms · reduced motion: static · origin: preset

### Screen 3 · Spot the parallel sides

- When Screen 3 · Spot the parallel sides opens → fade the screen in.
  - `anim-scn-trap-ide-scene-fade` · Fade · decorative · 320 ms · reduced motion: static · origin: preset
- When Screen 3 · Spot the parallel sides opens → play Swiftee's “wave” clip once (after “Fade” on Whole screen).
  - `anim-scn-trap-ide-character-` · Character clip · decorative · 1000 ms · reduced motion: static · origin: preset
- When Screen 3 · Spot the parallel sides opens → highlight Instruction panel with an outline (after “Character clip” on Swiftee).
  - `anim-scn-trap-ide-outline-hi` · Outline highlight · instructional · 1200 ms · reduced motion: stepwise · origin: preset
- When Screen 3 · Spot the parallel sides opens → give Item tray one gentle attention cue after 0.4 s.
  - `anim-scn-trap-ide-attention-` · Gentle attention cue · instructional · 700 ms after 400 ms · reduced motion: stepwise · origin: preset
- When an object lands on Target Has parallel sides on Screen 3 · Spot the parallel sides → snap Target Has parallel sides into place.
  - `anim-scn-trap-ide-drop-snap` · Valid-drop snap · feedback · 260 ms · reduced motion: skip · origin: preset
- When an object lands on Target No parallel sides on Screen 3 · Spot the parallel sides → snap Target No parallel sides into place.
  - `anim-scn-trap-ide-drop-snap-2` · Valid-drop snap · feedback · 260 ms · reduced motion: skip · origin: preset
- When an answer on Screen 3 · Spot the parallel sides is not right yet → outline Instruction panel to show where to look again.
  - `anim-scn-trap-ide-retry-cue` · Retry outline cue · feedback · 1200 ms · reduced motion: stepwise · origin: preset
- After the correct answer on Screen 3 · Spot the parallel sides → briefly highlight Instruction panel in the success colour.
  - `anim-scn-trap-ide-success-hi` · Brief success highlight · feedback · 800 ms · reduced motion: stepwise · origin: preset
- After the correct answer on Screen 3 · Spot the parallel sides → play the “celebrate” clip on Swiftee once.
  - `anim-scn-trap-ide-celebratio` · Celebration clip · decorative · 1000 ms · reduced motion: static · origin: preset

### Screen 4 · Match the shapes

- When Screen 4 · Match the shapes opens → fade the screen in.
  - `anim-scn-trap-mat-scene-fade` · Fade · decorative · 320 ms · reduced motion: static · origin: preset
- When Screen 4 · Match the shapes opens → play Swiftee's “wave” clip once (after “Fade” on Whole screen).
  - `anim-scn-trap-mat-character-` · Character clip · decorative · 1000 ms · reduced motion: static · origin: preset
- When Screen 4 · Match the shapes opens → highlight Instruction panel with an outline (after “Character clip” on Swiftee).
  - `anim-scn-trap-mat-outline-hi` · Outline highlight · instructional · 1200 ms · reduced motion: stepwise · origin: preset
- When Screen 4 · Match the shapes opens → give Item tray one gentle attention cue after 0.4 s.
  - `anim-scn-trap-mat-attention-` · Gentle attention cue · instructional · 700 ms after 400 ms · reduced motion: stepwise · origin: preset
- When an object lands on Target Trapezium on Screen 4 · Match the shapes → snap Target Trapezium into place.
  - `anim-scn-trap-mat-drop-snap` · Valid-drop snap · feedback · 260 ms · reduced motion: skip · origin: preset
- When an object lands on Target Parallelogram on Screen 4 · Match the shapes → snap Target Parallelogram into place.
  - `anim-scn-trap-mat-drop-snap-2` · Valid-drop snap · feedback · 260 ms · reduced motion: skip · origin: preset
- When an object lands on Target Kite on Screen 4 · Match the shapes → snap Target Kite into place.
  - `anim-scn-trap-mat-drop-snap-3` · Valid-drop snap · feedback · 260 ms · reduced motion: skip · origin: preset
- When an answer on Screen 4 · Match the shapes is not right yet → outline Instruction panel to show where to look again.
  - `anim-scn-trap-mat-retry-cue` · Retry outline cue · feedback · 1200 ms · reduced motion: stepwise · origin: preset
- After the correct answer on Screen 4 · Match the shapes → briefly highlight Instruction panel in the success colour.
  - `anim-scn-trap-mat-success-hi` · Brief success highlight · feedback · 800 ms · reduced motion: stepwise · origin: preset
- After the correct answer on Screen 4 · Match the shapes → play the “celebrate” clip on Swiftee once.
  - `anim-scn-trap-mat-celebratio` · Celebration clip · decorative · 1000 ms · reduced motion: static · origin: preset

### Screen 5 · Completion

- When Screen 5 · Completion opens → fade the screen in.
  - `anim-completion-scene-fade` · Fade · decorative · 320 ms · reduced motion: static · origin: preset
- When Screen 5 · Completion opens → play Swiftee's “wave” clip once (after “Fade” on Whole screen).
  - `anim-completion-character-` · Character clip · decorative · 1000 ms · reduced motion: static · origin: preset
- When Screen 5 · Completion opens → play the “celebrate” clip on Swiftee once (after “Character clip” on Swiftee).
  - `anim-completion-celebratio` · Celebration clip · decorative · 1200 ms · reduced motion: static · origin: preset

## Triggers

- `scene-entered` — when the screen opens
- `control-activated` — when a button is pressed
- `instruction-advanced` — when the learner reveals the next hint or step
- `object-selected` — when the learner selects an object
- `valid-drop` — when an object is placed in a valid spot
- `correct-answer` — when the answer is correct
- `retry-requested` — when an answer is checked and is not right yet
- `scene-completed` — when the screen is completed

## Runtime behaviour

- One deterministic, cancelable scheduler per screen; everything is cancelled when the screen exits, restarts or the game is disposed, and paused while the page is hidden.
- Dragging has priority: motion on a dragged object yields to the learner. Hit areas follow the objects; game state never depends on an animation finishing.
- Celebrations are short and skippable; there is no strobe, flashing or screen shake.
- Budgets: at most 24 animations per screen, 8 per trigger, 12 running at once and 40 particles per burst; low-effects mode removes particles.
- A single static picture only moves, fades, scales or rotates as a whole; waving or walking needs a sprite sheet with named clips.

## Not available (by design)

- **Lip sync / talking** — There is no speech or lip-sync generation, and no narration is invented. Instead: Use an uploaded talking clip (sprite frames) and an uploaded audio file, with captions in the instruction panel.
- **Waving, walking or talking from a single image** — A static image can only move, scale, fade or rotate as a whole. Instead: Upload frame images or a sprite sheet and set up named clips in Assets, or use a whole-object movement.
- **Screen shake** — Excluded: shaking is disorienting and reads as punishment. Instead: Use the retry outline cue.
- **Strobe or rapid flashing** — Excluded for safety (photosensitivity). Instead: Use an outline highlight.
- **Full-screen confetti** — Celebrations stay small and skippable so they never hide content. Instead: Use a small particle burst or a celebration clip.
- **Figma Smart Animate / prototype playback** — Prototype links and transitions are design evidence, not executable gameplay. Instead: Choose a supported scene transition (cut, fade or slide).
- **AI-generated animation frames** — No animation-generation service is connected. Instead: Draw or generate frames elsewhere, upload them, and build a sprite from them in Assets.

## Validation at export

- 28 animation(s) pass the target, trigger, budget and dependency checks.

No frame-rate, performance or accessibility-compliance claims are made by this export. Test on the devices learners will use, with reduced motion both on and off.

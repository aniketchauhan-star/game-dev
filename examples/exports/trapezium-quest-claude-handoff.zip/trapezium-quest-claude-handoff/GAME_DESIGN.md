# Game design — Trapezium Quest

**Audience:** Grade 8 · Mathematics  
**Core mechanic:** Drag-and-match
**Blueprint revision:** r1 · **Game version:** v1

## Premise
Swiftee the arctic bird is sorting ice floes by shape. Help spot the trapeziums by their parallel sides, then name every shape.

## Why this mechanic fits
Sorting and matching cards directly practises classifying shapes by their parallel sides.

## Learning outcomes
- Identify whether a quadrilateral is a trapezium by checking for at least one pair of parallel sides. _(source: slide 2, slide 3, slide 4)_
- Name trapeziums, parallelograms and kites by their most specific name. _(source: slide 4, slide 5)_

## Progression
An introduction with the lesson’s definition, a guided identification with hints, then a matching task that uses the most specific names.

## Assessment
Each sort is checked by a fixed rule from the lesson table; feedback points back to the parallel sides.

## Scene flow
Title screen → What is a trapezium? → Spot the parallel sides → Match the shapes → Completion screen

### 1. What is a trapezium? — Concept card (discover)
- **Source:** slide 2, slide 3
- **Objective:** Recall the definition of a trapezium.
- **Learner sees:** A concept card with the lesson’s definition and how to spot parallel sides.
- **Learner does:** Read the points and continue.
- **Expected result:** The learner continues to the identification task.
- **Success rule:** Continue after reading
- **Instruction:** “A trapezium has at least one pair of parallel sides.”
- **Error feedback:** “Read the points, then continue.”
- **Hints:** “Look for sides that never meet.”
- **Completion:** The learner selects Start the expedition.
- **Locks:** sequence

### 2. Spot the parallel sides — Drag-and-match (manipulate)
- **Source:** slide 3, slide 4
- **Objective:** Decide whether each shape has at least one pair of parallel sides.
- **Learner sees:** Three shape cards and two bays: “Has parallel sides” and “No parallel sides”.
- **Learner does:** Place each shape in a bay.
- **Expected result:** The trapezium and the parallelogram have parallel sides; the kite has none.
- **Success rule:** Shape A → Has parallel sides; Shape B → Has parallel sides; Shape C → No parallel sides
- **Instruction:** “Drag each shape to the right group.”
- **Error feedback:** “Check each shape for sides that never meet.”
- **Hints:** “Arrow marks show parallel sides.” → “A parallelogram has two pairs — that still counts.”
- **Completion:** All three shapes are in the correct bay.
- **Locks:** sequence

### 3. Match the shapes — Drag-and-match (apply)
- **Source:** slide 4, slide 5
- **Objective:** Name each shape by its most specific name.
- **Learner sees:** Three shape cards and three name bays: Trapezium, Parallelogram, Kite.
- **Learner does:** Place each shape on its name.
- **Expected result:** Each shape is on its most specific name.
- **Success rule:** Shape 1 → Trapezium; Shape 2 → Parallelogram; Shape 3 → Kite
- **Instruction:** “Match each shape to its most specific name.”
- **Error feedback:** “A parallelogram is also a trapezium, but its most specific name is parallelogram.”
- **Hints:** “Count the pairs of parallel sides first.” → “Two pairs: parallelogram. One pair: trapezium. None: kite.”
- **Completion:** All shapes are on their names.
- **Locks:** sequence

## Accessibility requirements
- Every card can be selected and placed with clicks or keys — no dragging required.
- Feedback uses words and icons, never colour alone.
- Motion follows the reduced-motion setting.

## Assumptions (not stated in the source)
- The lesson’s inclusive definition is used throughout (parallelograms are trapeziums).

## Unresolved decisions
- (none)

# GRADE PROFILE

Grade version: **Main** (game version 1).

- Who it is for: **Grade 8**
- Language: en · input: mixed
- Profile revision 1 · seeded from the “Grades 6–8” product preset

## Separate settings

- Difficulty: core
- Reading support: standard (text length, key terms and step lists — not a reading level)
- Guidance: Standard
- Motion: guided, standard pacing, decorative low, sound on
- For everyone: low motion available, untimed yes, keyboard yes, extra guidance available

> Product presets — starting suggestions you can change, not scientifically validated grade rules. Nothing here infers a learner's age, ability, diagnosis or reading level.

## Grade adaptation plans applied

### Plan 1 — presentation only (prepared demo answer)

Grade 8 (Grades 6–8 preset): a challenge framing for the identification task, step-by-step hints that keep the lesson’s inclusive definition, cleaner panels, and motion that explains relationships.

- [language] Turn the instruction into a clear question that names the rule. · source: sld_wqIg8P5C21j0, sld_ispChXj7leuk
- [hints] Three progressive hints instead of two. · source: sld_wqIg8P5C21j0, sld_ispChXj7leuk
- [feedback] Error feedback that points to the reasoning step. · source: sld_ispChXj7leuk, sld_ak6zTEiaUV4s
- [layout] Cleaner, more compact instruction panels.

Assumptions:
- Learners have met parallel lines before (prerequisite from the lesson).
- The Grades 6–8 product preset is a starting point, not a validated rule.

Curriculum: Curriculum alignment is not verified.


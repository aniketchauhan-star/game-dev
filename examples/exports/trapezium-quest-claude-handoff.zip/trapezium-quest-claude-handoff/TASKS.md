# TASKS

## Requested next changes
Add a fourth scene that sorts quadrilaterals by number of parallel pairs.

## Source content to double-check
- Slide 2 “What is a trapezium?” is not yet verified by the creator.
- Slide 3 “Spot the parallel sides” is not yet verified by the creator.
- Slide 4 “Trapezium or not?” is not yet verified by the creator.
- Slide 5 “Match the shapes” is not yet verified by the creator.

## Known limitations
- The export preflight does not run browser tests; playtest in a browser.
- Images are used as supplied; check licensing before publishing.

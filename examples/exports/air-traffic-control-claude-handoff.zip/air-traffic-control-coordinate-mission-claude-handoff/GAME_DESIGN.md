# Game design — Air Traffic Control — Coordinate Mission

**Audience:** Grade 9 · Mathematics  
**Core mechanic:** Coordinate navigation
**Blueprint revision:** r1 · **Game version:** v1

## Premise
You are the air traffic controller. Flights radio in with coordinates, and you guide each aircraft across an airfield laid out on a coordinate grid.

## Why this mechanic fits
The lesson is about locating positions from ordered pairs, so moving an aircraft to a coordinate makes learners perform exactly the skill being taught: move along x, then along y. A matching scene and an ordering scene check the related quadrant and comparison ideas without switching to a generic quiz.

## Learning outcomes
- Locate and plot a point from an ordered pair (x, y), moving along x first and then y. _(source: slide 2, slide 3, slide 7)_
- Identify the quadrant of a point from the signs of its coordinates. _(source: slide 4)_
- Interpret negative coordinates as movement to the left or downward. _(source: slide 5)_
- Compare and order points by their x-coordinates. _(source: slide 9)_

## Progression
Starts with the target marked and a live coordinate readout, then removes the marker, then accepts any point in a quadrant, and finishes by ordering aircraft by x-coordinate.

## Assessment
Every scene is checked with a deterministic rule (exact point, quadrant, matches or order). Feedback names common mistakes such as swapped coordinates or sign errors, and hints become more explicit after each attempt.

## Scene flow
Title screen → Welcome to the tower → Taxi to Runway Alpha → Which quadrant? → Hangar check → Holding pattern → Line up for take-off → Completion screen

### 1. Welcome to the tower — Concept card (discover)
- **Source:** slide 2, slide 3
- **Objective:** Recognize the axes, the origin and what an ordered pair means.
- **Learner sees:** A concept card over a small coordinate grid with three short points about the axes and ordered pairs.
- **Learner does:** Read the three points and continue.
- **Expected result:** The learner moves on to the first navigation task.
- **Success rule:** Continue after reading
- **Instruction:** “Your airfield is a coordinate grid.”
- **Error feedback:** “Read the three points, then choose Start mission.”
- **Hints:** “x comes first, then y.”
- **Completion:** The learner selects Start mission.
- **Locks:** sequence

### 2. Taxi to Runway Alpha — Coordinate navigation (manipulate)
- **Source:** slide 3, slide 7
- **Objective:** Move to a point given as an ordered pair, x first then y.
- **Learner sees:** Airfield grid from −5 to 5 across and −4 to 4 up; flight NX7 at the origin; Runway Alpha marked at (3, 2).
- **Learner does:** Move the aircraft with the arrow buttons, arrow keys or by selecting a grid point, then confirm.
- **Expected result:** The aircraft stops exactly at (3, 2).
- **Success rule:** Reach (3, 2)
- **Instruction:** “Guide flight NX7 to Runway Alpha at (3, 2).”
- **Error feedback:** “Check the order: move along x first, then along y.”
- **Hints:** “Start at the origin, (0, 0).” → “x = 3: move 3 units right.” → “y = 2: then move 2 units up.”
- **Completion:** The aircraft is confirmed at (3, 2).
- **Locks:** sequence

### 3. Which quadrant? — Drag-and-match (predict)
- **Source:** slide 4, slide 5
- **Objective:** Identify a point's quadrant from the signs of its coordinates.
- **Learner sees:** Six aircraft position cards and five bays: Quadrant I, II, III, IV and On an axis.
- **Learner does:** Drag each card into a bay, or select a card and then a bay.
- **Expected result:** Every position is in its correct quadrant; (0, 4) is on an axis.
- **Success rule:** (2, 3) → Quadrant I; (5, 1) → Quadrant I; (−4, 1) → Quadrant II; (−3, −2) → Quadrant III; (4, −1) → Quadrant IV; (0, 4) → On an axis
- **Instruction:** “Sort each aircraft position into its quadrant.”
- **Error feedback:** “Look at the signs: x tells left (−) or right (+), y tells down (−) or up (+).”
- **Hints:** “Quadrant I has both coordinates positive.” → “Quadrant II: x negative, y positive. Quadrant IV: x positive, y negative.” → “A zero coordinate puts the point on an axis.”
- **Completion:** All six cards are in a correct bay.
- **Locks:** sequence

### 4. Hangar check — Coordinate navigation (test)
- **Source:** slide 5
- **Objective:** Use negative coordinates to locate a point without a marker.
- **Learner sees:** The same airfield grid, no target marker; flight QF2 at the origin.
- **Learner does:** Move the aircraft to (−4, −3) and confirm.
- **Expected result:** The aircraft stops exactly at (−4, −3).
- **Success rule:** Reach (−4, −3)
- **Instruction:** “Park flight QF2 at the hangar: (−4, −3).”
- **Error feedback:** “Check the signs: negative x is left, negative y is down.”
- **Hints:** “Negative x means left of the y-axis.” → “Move 4 units left, then 3 units down.” → “Both coordinates are negative, so the hangar is in Quadrant III.”
- **Completion:** The aircraft is confirmed at (−4, −3).
- **Locks:** sequence

### 5. Holding pattern — Coordinate navigation (apply)
- **Source:** slide 9, slide 4
- **Objective:** Apply quadrant signs to choose any valid point.
- **Learner sees:** The airfield grid; flight BA9 starts at (2, −1).
- **Learner does:** Move the aircraft to any point in Quadrant II and confirm.
- **Expected result:** The aircraft ends with negative x and positive y.
- **Success rule:** Finish anywhere in Quadrant II
- **Instruction:** “Park flight BA9 anywhere in Quadrant II.”
- **Error feedback:** “Quadrant II is top left: x must be negative and y positive.”
- **Hints:** “Quadrant II is the top-left part of the grid.” → “x must be negative and y must be positive.” → “For example, (−2, 2) is in Quadrant II.”
- **Completion:** The aircraft is confirmed in Quadrant II.
- **Locks:** sequence

### 6. Line up for take-off — Sequence sorting (apply)
- **Source:** slide 9
- **Objective:** Order points by their x-coordinates.
- **Learner sees:** Five aircraft cards with their positions, to be arranged in a row.
- **Learner does:** Arrange the cards from left (smallest x) to right (largest x).
- **Expected result:** Cards ordered by x; the two with x = 1 may be in either order.
- **Success rule:** Order from smallest to largest value (equal values may go in either order)
- **Instruction:** “Line up the aircraft from left to right by x-coordinate.”
- **Error feedback:** “Compare the first number of each pair: a smaller x goes further left.”
- **Hints:** “Only the x-coordinate (the first number) matters.” → “Negative x values go furthest left.” → “QF2 and BA9 both have x = 1, so either order is fine.”
- **Completion:** All five cards are in a correct order.
- **Locks:** sequence

## Accessibility requirements
- Every move works with arrow keys, on-screen buttons, or by selecting a grid point — no dragging required.
- Feedback uses text and icons, never color alone.
- Respects the reduced-motion setting and starts sound only after the learner presses Start.

## Assumptions (not stated in the source)
- Grade 9 learners already know negative numbers on a number line.
- Learners play individually on a laptop or tablet.

## Unresolved decisions
- Include the distance-formula extension (slide 8) as optional practice? Options: Leave it out / Add an optional scene

# Air Traffic Control — Coordinate Mission — source package

Exported from NEXUS Play Studio (game version 1).

## What is here

| Path | Purpose |
| --- | --- |
| `game.config.json` | The whole game as data: scenes, rules, feedback, theme. Edit this. |
| `asset-map.json` | Which asset file is used where, with crop/scale/anchor metadata. |
| `assets/` | Asset files used by the game. `assets/originals/` keeps the original uploads. |
| `runtime/` | The prebuilt NEXUS runtime (plain JavaScript and CSS). |
| `runtime-src/` | TypeScript source of the runtime and the shared rule engine. |
| `index.html` | Page template. |
| `build.mjs` | Validates `game.config.json` and writes a playable site to `dist/`. |
| `serve.mjs` | Serves `dist/` on http://127.0.0.1:8080 for testing. |

## Build

Requires Node.js 18 or later. No dependencies are installed.

```sh
node build.mjs     # writes dist/
node serve.mjs     # open http://127.0.0.1:8080
```

Answer rules are data (for example `{"kind":"point-equals","target":{"x":3,"y":2}}`) and are evaluated by
trusted code in the runtime — never write formulas or code into the configuration.

## Not included

API keys, environment files, studio conversations, the original slide deck and speaker notes are never part of
this package unless “Include source material” was selected (then see `source-material/`).

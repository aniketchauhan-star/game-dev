# TASKS

## Requested next changes
Add a fifth coordinate scene that uses negative y targets.

## Source content to double-check
- Slide 2 “The airfield is a coordinate plane” is not yet verified by the creator.
- Slide 3 “Reading an ordered pair (x, y)” is not yet verified by the creator.
- Slide 3: Slide uses animations (1 effect). Explanations that depend on build order may not be captured — check the sequence.
- Slide 4 “The four quadrants” is not yet verified by the creator.
- Slide 5 “Negative coordinates” is not yet verified by the creator.
- Slide 7 “Tower to runway: plotting steps” is not yet verified by the creator.
- Slide 9 “Mission practice” is not yet verified by the creator.

## Unresolved design decisions
- Include the distance-formula extension (slide 8) as optional practice?

## Known limitations
- The export preflight does not run browser tests; playtest in a browser.
- Images are used as supplied; check licensing before publishing.

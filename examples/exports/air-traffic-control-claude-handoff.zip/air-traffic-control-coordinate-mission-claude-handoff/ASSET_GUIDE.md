# ASSET GUIDE

## Assets in this export
| Name | Role | Kind | Size | Transparency | Source | File |
| --- | --- | --- | --- | --- | --- | --- |
| aircraft | character | image | 320×320 | yes | bundled-sample | `assets/ast_t8s1oszQ04v0.png` |
| airfield-map | background | image | 1600×900 | yes | bundled-sample | `assets/ast_K0TC6v0211wW.png` |

Placement metadata (scale, rotation, anchor, crop) and sprite-sheet settings are in `asset-map.json`.

## Asset needs from the blueprint
- **Top-down airfield map (from slide 9)** (background) — assigned
- **The aircraft the learner guides (from slide 7)** (character, required) — assigned

## Generation prompts
NEXUS does not generate images. If you need new artwork, these prompts can be pasted into an image tool of your choice:
- (all needs are assigned)

# ANIMATION GUIDE

Animations are **data** (`game.config.json` → `motion`), validated by `runtime-src/shared/schemas/motion.ts` and run by the trusted runtime (`runtime-src/runtime/motion/`).
They are bound to runtime events (screen opened, control pressed, valid drop, correct answer, retry, completion…). Motion never submits answers, awards points, changes progress or replays sounds on its own.

## Settings

- Profile: **guided** · pacing: **calm** · decorative effects: **low**
- Animation sounds: on (volume 70%) — uploaded or bundled audio only, after the learner presses Start
- Reduced motion: follows the learner's device setting · low-effects mode: off

## Rules by screen

### Screen 1 · Title

_No animations._

### Screen 2 · Welcome to the tower

_No animations._

### Screen 3 · Taxi to Runway Alpha

_No animations._

### Screen 4 · Which quadrant?

_No animations._

### Screen 5 · Hangar check

_No animations._

### Screen 6 · Holding pattern

_No animations._

### Screen 7 · Line up for take-off

_No animations._

### Screen 8 · Completion

_No animations._

## Triggers

- `scene-entered` — when the screen opens
- `control-activated` — when a button is pressed
- `instruction-advanced` — when the learner reveals the next hint or step
- `object-selected` — when the learner selects an object
- `valid-drop` — when an object is placed in a valid spot
- `correct-answer` — when the answer is correct
- `retry-requested` — when an answer is checked and is not right yet
- `scene-completed` — when the screen is completed

## Runtime behaviour

- One deterministic, cancelable scheduler per screen; everything is cancelled when the screen exits, restarts or the game is disposed, and paused while the page is hidden.
- Dragging has priority: motion on a dragged object yields to the learner. Hit areas follow the objects; game state never depends on an animation finishing.
- Celebrations are short and skippable; there is no strobe, flashing or screen shake.
- Budgets: at most 24 animations per screen, 8 per trigger, 12 running at once and 40 particles per burst; low-effects mode removes particles.
- A single static picture only moves, fades, scales or rotates as a whole; waving or walking needs a sprite sheet with named clips.

## Not available (by design)

- **Lip sync / talking** — There is no speech or lip-sync generation, and no narration is invented. Instead: Use an uploaded talking clip (sprite frames) and an uploaded audio file, with captions in the instruction panel.
- **Waving, walking or talking from a single image** — A static image can only move, scale, fade or rotate as a whole. Instead: Upload frame images or a sprite sheet and set up named clips in Assets, or use a whole-object movement.
- **Screen shake** — Excluded: shaking is disorienting and reads as punishment. Instead: Use the retry outline cue.
- **Strobe or rapid flashing** — Excluded for safety (photosensitivity). Instead: Use an outline highlight.
- **Full-screen confetti** — Celebrations stay small and skippable so they never hide content. Instead: Use a small particle burst or a celebration clip.
- **Figma Smart Animate / prototype playback** — Prototype links and transitions are design evidence, not executable gameplay. Instead: Choose a supported scene transition (cut, fade or slide).
- **AI-generated animation frames** — No animation-generation service is connected. Instead: Draw or generate frames elsewhere, upload them, and build a sprite from them in Assets.

## Validation at export

- 0 animation(s) pass the target, trigger, budget and dependency checks.

No frame-rate, performance or accessibility-compliance claims are made by this export. Test on the devices learners will use, with reduced motion both on and off.

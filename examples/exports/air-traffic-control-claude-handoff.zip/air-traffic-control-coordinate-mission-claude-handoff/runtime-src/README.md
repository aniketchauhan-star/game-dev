# Runtime source

`runtime/` is the NEXUS game runtime (TypeScript, no framework). `shared/` holds the schemas, coordinate math and the allowlisted rule engine it uses.
The prebuilt bundle is in `../runtime/`. To rebuild, bundle `runtime/main.ts` as an IIFE with Vite or esbuild (alias `@shared` → `./shared`) and the dependency `zod`.
